#!/bin/bash 


# Comments enhance the verbosity of the scripts by making it more descriptive.

# In a scirpt, if you want to test something and if you want to eliminate some lines and run the script, then you can comment then, If you command, system don't recorgnize it as executable.

echo "This is to demonstrate the usage of single line and multi-line comments"

<<COMMENT
a=10 
echo $a
echo "In this infinite world we are just star dust"
echo "This is to demonstrate multi line comments"
COMMENT
