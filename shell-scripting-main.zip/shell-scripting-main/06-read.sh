#!/bin/bash 

read -p "Enter your name :" name 
echo -e "Name of the entered value is $name"
