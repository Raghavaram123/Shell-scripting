#!/bin/bash 

bash components/$1.sh