#!/bin/bash 

echo "I am mysql"