#!/bin/bash 

# What is a loop ?
# If you want to execure something certain number of times, the we use loop   

# for loop is a very famour loop when you know whoe many number of times, we need to to run. 

# For loop syntax : 
for val in x y z 1 2 3 ; do
    echo "value of variable is $val"
done 


