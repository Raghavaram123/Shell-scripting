#!/bin/bash 

a=10

if  [ -z "$a" ] ; then 
    echo "Value of a is declared"

else 
    echo "Value of a is not declared"

fi 


